package com.timebanking.firebase;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.support.annotation.NonNull;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.Toast;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AddJobActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener{

    private EditText inputTitle, inputDesc, inputLocation;
    int inputMinutes;
    private DatabaseReference mFirebaseDatabase;
    private FirebaseDatabase mFirebaseInstance;
    private String userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_job);
        Button btnAdd;

        inputTitle = findViewById(R.id.EditTextJobTitle);
        inputDesc = findViewById(R.id.EditTextJobDesc);
        inputLocation = findViewById(R.id.address);
        btnAdd = findViewById(R.id.btn_add);

        Spinner paySpinner = (Spinner) findViewById(R.id.spinner1);
        paySpinner.setOnItemSelectedListener(this);
        ArrayAdapter<String> myAdapter = new ArrayAdapter<String>(AddJobActivity.this, android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.pay_amounts));
        myAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        paySpinner.setAdapter(myAdapter);
       // inputMinutes = Integer.parseInt(paySpinner.getSelectedItem().toString());

        mFirebaseInstance = FirebaseDatabase.getInstance();

        // get reference to 'users' node
        mFirebaseDatabase = mFirebaseInstance.getReference("jobs");

        // store app title to 'app_title' node
        mFirebaseInstance.getReference("app_title").setValue("Realtime Database");

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final String title = inputTitle.getText().toString().trim();
                final String desc = inputDesc.getText().toString().trim();
                final String location = inputLocation.getText().toString().trim();

                if (TextUtils.isEmpty(title)) {
                    Toast.makeText(getApplicationContext(), "Enter job title!", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (TextUtils.isEmpty(desc)) {
                    Toast.makeText(getApplicationContext(), "Enter job description!", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (TextUtils.isEmpty(location)) {
                    Toast.makeText(getApplicationContext(), "Enter job location!", Toast.LENGTH_SHORT).show();
                    return;
                }


                if (inputMinutes > 30) {
                    Toast.makeText(getApplicationContext(), "Not enough minutes!", Toast.LENGTH_SHORT).show();
                    return;
                }
                else {
                    //create job
                    createJob(title, desc, location, inputMinutes);
                    startActivity(new Intent(AddJobActivity.this, MainActivity.class));
                    finish();
                }

            }
        });
    }

    private void createJob(String title, String desc, String location, int minutes) {
        FirebaseAuth mFirebaseAuth = FirebaseAuth.getInstance();
        FirebaseUser mFirebaseUser = mFirebaseAuth.getCurrentUser();
        userId = mFirebaseUser.getUid();
        String jobId = "";

        if (TextUtils.isEmpty(jobId)) {
            jobId = mFirebaseDatabase.push().getKey();
        }
        Job job = new Job(title, desc, minutes, location, userId);

        mFirebaseDatabase.child(jobId).setValue(job);

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        inputMinutes = Integer.parseInt(parent.getSelectedItem().toString());
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
    }
}