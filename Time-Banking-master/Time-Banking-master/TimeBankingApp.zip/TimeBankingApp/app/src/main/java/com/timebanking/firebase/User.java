package com.timebanking.firebase;

import com.google.firebase.database.IgnoreExtraProperties;

@IgnoreExtraProperties
public class User {
    public String name, email;
    public int minutes;

    /* Default constructor required for calls to DataSnapshot.getValue(User.class)*/
    public User(){}

    public User(String name, String email, int minutes){
        this.name = name;
        this.email = email;
        this.minutes = minutes;
    }
}
