package com.timebanking.firebase;

import com.google.firebase.database.IgnoreExtraProperties;

@IgnoreExtraProperties
public class Job {
    public String title, desc;
    public int pay;
    public String userId;
    public String address;

    /* Default constructor required for calls to DataSnapshot.getValue(User.class)*/
    public Job(){}

    public Job(String title, String desc, int pay, String address, String userId){
        this.title = title;
        this.desc = desc;
        this.pay = pay;
        this.userId = userId;
        this.address = address;
    }
}
